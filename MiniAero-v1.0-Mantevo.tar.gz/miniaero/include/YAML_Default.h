
#ifndef INCLUDE_YAML_DEFAULT_H_
#define INCLUDE_YAML_DEFAULT_H_

#ifndef MINIAERO_HOSTNAME
#define MINIAERO_HOSTNAME "unknown"
#endif
#ifndef MINIAERO_PROCESSOR
#define MINIAERO_PROCESSOR "unknown"
#endif
#ifndef MINIAERO_CXX
#define MINIAERO_CXX "unknown"
#endif
#ifndef MINIAERO_CXXFLAGS
#define MINIAERO_CXXFLAGS "unknown"
#endif


#endif
