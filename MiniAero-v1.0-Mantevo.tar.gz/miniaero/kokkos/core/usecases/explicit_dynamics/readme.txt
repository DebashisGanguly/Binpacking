Material properties and calculations omitted

APS and Hex namespaces omitted
