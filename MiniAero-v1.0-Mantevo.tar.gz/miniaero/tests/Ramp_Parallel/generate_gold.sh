#!/bin/bash
for i in `seq 0 15`;
do 
  cp results.$i results.$i.gold
done
